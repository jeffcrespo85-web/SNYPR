# SNYPR

Job recon app for Android. Press one button and SNYPR spends up to 60 seconds sweeping company career boards for postings published in the last 1, 6 or 24 hours, filtered by keyword, exclusion and location.

## Get the APK

1. Create a new GitHub repo and push the contents of this folder to the `main` branch.
2. Open the **Actions** tab. The "Build SNYPR APK" workflow runs on every push (about 4 minutes the first time).
3. When it finishes, download `SNYPR-debug.apk` from the **Releases** page of your repo (works from a phone browser), or from the run's **Artifacts**.
4. On the phone, allow "install unknown apps" for your browser or files app, then open the APK.

Local build, if you have the Android SDK and Gradle 8.7+: `gradle assembleDebug`. Output: `app/build/outputs/apk/debug/app-debug.apk`. The debug APK is signed with the auto-generated debug key, which is fine for testing.

## How it works

Most company career pages are front-ends for a hiring system with a public JSON feed that includes the posting time. SNYPR reads those feeds directly, in parallel, with no LinkedIn or aggregator in between:

| System | Posting time used |
|---|---|
| Greenhouse | `first_published` (falls back to `updated_at`, flagged "Updated" on the card) |
| Lever | `createdAt` |
| Ashby | `publishedAt` |
| SmartRecruiters | `releasedDate` (first 300 postings per company) |
| Recruitee | `published_at` |

- **Armory** is the list of company boards to sweep. A starter list ships with the app. Paste any company careers page link and tap ADD, and SNYPR detects which system it runs on. Boards that return "not found" are flagged and can be removed in MANAGE ARMORY.
- **NEW** marks postings SNYPR has not shown you in an earlier sweep.
- Tap a contact to open the posting.

## Known limits

- Only the five systems above. Workday, iCIMS, Taleo, SuccessFactors and fully custom career sites are not covered (Workday only publishes day-level dates, so it cannot support an hour filter).
- Pasting a careers link only works when the board link is visible in the page HTML. Pages that build themselves with JavaScript may need the direct board link (for example `boards.greenhouse.io/<company>`).
- The starter armory slugs are unverified guesses at common companies. Expect some to be flagged "not found".
- Debug build only, not for the Play Store.
