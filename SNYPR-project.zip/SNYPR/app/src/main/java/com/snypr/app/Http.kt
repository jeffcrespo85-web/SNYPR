package com.snypr.app

import java.net.HttpURLConnection
import java.net.URL

class Resp(val code: Int, val body: String?)

object Http {
    private const val MAX_CHARS = 8_000_000

    /** code = HTTP status, or -1 on a network error. body only for 2xx. */
    fun get(url: String, timeoutMs: Int): Resp {
        var conn: HttpURLConnection? = null
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            conn = c
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) SNYPR/1.0")
            c.setRequestProperty("Accept", "application/json, text/html;q=0.9, */*;q=0.5")
            val code = c.responseCode
            if (code in 200..299) {
                val sb = StringBuilder()
                c.inputStream.bufferedReader().use { r ->
                    val buf = CharArray(8192)
                    while (true) {
                        val n = r.read(buf)
                        if (n < 0) break
                        sb.append(buf, 0, n)
                        if (sb.length > MAX_CHARS) break
                    }
                }
                Resp(code, sb.toString())
            } else {
                Resp(code, null)
            }
        } catch (e: Exception) {
            Resp(-1, null)
        } finally {
            conn?.disconnect()
        }
    }
}
