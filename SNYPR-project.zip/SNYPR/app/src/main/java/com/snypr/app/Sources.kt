package com.snypr.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.time.Instant
import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

internal fun JSONObject.str(name: String): String = if (isNull(name)) "" else optString(name, "")

internal fun parseIso(s: String): Long? {
    if (s.isBlank()) return null
    return try {
        OffsetDateTime.parse(s).toInstant().toEpochMilli()
    } catch (e: Exception) {
        try {
            Instant.parse(s).toEpochMilli()
        } catch (e2: Exception) {
            null
        }
    }
}

internal fun isRemoteText(s: String): Boolean = s.contains("remote", ignoreCase = true)

/**
 * Public job-board endpoints that companies' own career pages are built on.
 * Every one of these returns a machine-readable posting time.
 */
object Sources {
    const val BAD_DATA = -2
    const val TIMED_OUT = -3
    private const val PER_REQUEST_MS = 8000L

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    private fun get(url: String, deadline: Long): Resp {
        val left = deadline - System.currentTimeMillis()
        val to = minOf(PER_REQUEST_MS, left).toInt()
        if (to < 400) return Resp(TIMED_OUT, null)
        return Http.get(url, to)
    }

    fun fetch(t: Target, deadline: Long): FetchResult = when (t.ats) {
        Ats.GREENHOUSE -> greenhouse(t, deadline)
        Ats.LEVER -> lever(t, deadline)
        Ats.ASHBY -> ashby(t, deadline)
        Ats.SMARTRECRUITERS -> smartRecruiters(t, deadline)
        Ats.RECRUITEE -> recruitee(t, deadline)
    }

    // Each adapter is split in two: a network call, and a parser that takes the response body.
    // Parsers throw on malformed data; the network wrappers turn that into BAD_DATA.

    private inline fun wrap(r: Resp, parse: (String) -> List<Job>): FetchResult {
        val body = r.body ?: return FetchResult(r.code, emptyList())
        return try {
            FetchResult(r.code, parse(body))
        } catch (e: Exception) {
            FetchResult(BAD_DATA, emptyList())
        }
    }

    private fun greenhouse(t: Target, deadline: Long): FetchResult =
        wrap(get("https://boards-api.greenhouse.io/v1/boards/${enc(t.slug)}/jobs", deadline)) { parseGreenhouse(t, it) }

    internal fun parseGreenhouse(t: Target, body: String): List<Job> {
        val out = ArrayList<Job>()
        val arr = JSONObject(body).optJSONArray("jobs") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val first = parseIso(o.str("first_published"))
            val upd = parseIso(o.str("updated_at"))
            val ts = first ?: upd ?: continue
            val loc = o.optJSONObject("location")?.str("name") ?: ""
            out.add(Job(t.name, o.str("title"), loc, o.str("absolute_url"), ts, first == null, isRemoteText(loc), t.ats))
        }
        return out
    }

    private fun lever(t: Target, deadline: Long): FetchResult =
        wrap(get("https://api.lever.co/v0/postings/${enc(t.slug)}?mode=json", deadline)) { parseLever(t, it) }

    internal fun parseLever(t: Target, body: String): List<Job> {
        val out = ArrayList<Job>()
        val arr = JSONArray(body)
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val created = o.optLong("createdAt", 0L)
            if (created <= 0L) continue
            val loc = o.optJSONObject("categories")?.str("location") ?: ""
            val remote = o.str("workplaceType").equals("remote", ignoreCase = true) || isRemoteText(loc)
            out.add(Job(t.name, o.str("text"), loc, o.str("hostedUrl"), created, false, remote, t.ats))
        }
        return out
    }

    private fun ashby(t: Target, deadline: Long): FetchResult =
        wrap(get("https://api.ashbyhq.com/posting-api/job-board/${enc(t.slug)}", deadline)) { parseAshby(t, it) }

    internal fun parseAshby(t: Target, body: String): List<Job> {
        val out = ArrayList<Job>()
        val arr = JSONObject(body).optJSONArray("jobs") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (!o.optBoolean("isListed", true)) continue
            val ts = parseIso(o.str("publishedAt")) ?: continue
            val loc = o.str("location")
            val remote = o.optBoolean("isRemote", false) || isRemoteText(loc)
            out.add(Job(t.name, o.str("title"), loc, o.str("jobUrl"), ts, false, remote, t.ats))
        }
        return out
    }

    private fun smartRecruiters(t: Target, deadline: Long): FetchResult {
        val out = ArrayList<Job>()
        var offset = 0
        var code = -1
        var page = 0
        while (page < 3) {
            val r = get("https://api.smartrecruiters.com/v1/companies/${enc(t.slug)}/postings?limit=100&offset=$offset", deadline)
            code = r.code
            val body = r.body ?: return FetchResult(r.code, out)
            try {
                val total = parseSmartRecruiters(t, body, out)
                offset += 100
                page++
                if (offset >= total) break
            } catch (e: Exception) {
                return FetchResult(BAD_DATA, emptyList())
            }
        }
        return FetchResult(code, out)
    }

    /** Appends the page's postings to [out] and returns the board's total posting count. */
    internal fun parseSmartRecruiters(t: Target, body: String, out: MutableList<Job>): Int {
        val root = JSONObject(body)
        val arr = root.optJSONArray("content") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val ts = parseIso(o.str("releasedDate")) ?: continue
            val l = o.optJSONObject("location")
            val loc = if (l == null) "" else listOf(l.str("city"), l.str("region"), l.str("country").uppercase())
                .filter { it.isNotBlank() }.joinToString(", ")
            val remote = (l?.optBoolean("remote", false) ?: false) || isRemoteText(loc)
            val url = "https://jobs.smartrecruiters.com/${t.slug}/${o.str("id")}"
            out.add(Job(t.name, o.str("name"), loc, url, ts, false, remote, t.ats))
        }
        return root.optInt("totalFound", 0)
    }

    private val recruiteeFmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")

    internal fun parseRecruiteeDate(s: String): Long? {
        val clean = s.removeSuffix("UTC").trim()
        return try {
            LocalDateTime.parse(clean, recruiteeFmt).toInstant(ZoneOffset.UTC).toEpochMilli()
        } catch (e: Exception) {
            parseIso(s)
        }
    }

    private fun recruitee(t: Target, deadline: Long): FetchResult {
        if (!Regex("[a-z0-9-]+").matches(t.slug)) return FetchResult(404, emptyList())
        return wrap(get("https://${t.slug}.recruitee.com/api/offers/", deadline)) { parseRecruitee(t, it) }
    }

    internal fun parseRecruitee(t: Target, body: String): List<Job> {
        val out = ArrayList<Job>()
        val arr = JSONObject(body).optJSONArray("offers") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val ts = parseRecruiteeDate(o.str("published_at")) ?: continue
            val loc = o.str("location")
            val remote = o.optBoolean("remote", false) || isRemoteText(loc)
            out.add(Job(t.name, o.str("title"), loc, o.str("careers_url"), ts, false, remote, t.ats))
        }
        return out
    }
}
