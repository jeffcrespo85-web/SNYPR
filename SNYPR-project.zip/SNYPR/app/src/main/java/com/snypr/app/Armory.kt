package com.snypr.app

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** The list of company boards SNYPR sweeps. Starter list is unverified; dead boards get flagged. */
object Armory {

    private fun gh(n: String, s: String) = Target(n, Ats.GREENHOUSE, s)
    private fun lv(n: String, s: String) = Target(n, Ats.LEVER, s)
    private fun ab(n: String, s: String) = Target(n, Ats.ASHBY, s)
    private fun sr(n: String, s: String) = Target(n, Ats.SMARTRECRUITERS, s)

    val seed: List<Target> = listOf(
        gh("Anthropic", "anthropic"), gh("Stripe", "stripe"), gh("Airbnb", "airbnb"),
        gh("Cloudflare", "cloudflare"), gh("Datadog", "datadog"), gh("Okta", "okta"),
        gh("Twilio", "twilio"), gh("Coinbase", "coinbase"), gh("Robinhood", "robinhood"),
        gh("Duolingo", "duolingo"), gh("Discord", "discord"), gh("Figma", "figma"),
        gh("Reddit", "reddit"), gh("Pinterest", "pinterest"), gh("Dropbox", "dropbox"),
        gh("GitLab", "gitlab"), gh("Instacart", "instacart"), gh("Lyft", "lyft"),
        gh("MongoDB", "mongodb"), gh("Elastic", "elastic"), gh("Asana", "asana"),
        gh("Databricks", "databricks"), gh("Brex", "brex"), gh("Gusto", "gusto"),
        gh("Affirm", "affirm"), gh("Carta", "carta"), gh("Chime", "chime"),
        gh("Roblox", "roblox"), gh("Samsara", "samsara"), gh("PagerDuty", "pagerduty"),
        gh("Fastly", "fastly"), gh("Checkr", "checkr"), gh("Scale AI", "scaleai"),
        gh("Vercel", "vercel"), gh("Webflow", "webflow"), gh("Mixpanel", "mixpanel"),
        gh("Intercom", "intercom"), gh("Grammarly", "grammarly"), gh("Squarespace", "squarespace"),
        gh("SentinelOne", "sentinelone"), gh("Huntress", "huntress"), gh("Abnormal Security", "abnormalsecurity"),
        gh("Arctic Wolf", "arcticwolf"), gh("Expel", "expel"), gh("Tanium", "tanium"),
        gh("Rubrik", "rubrik"),
        lv("Palantir", "palantir"), lv("Spotify", "spotify"), lv("Plaid", "plaid"),
        lv("Mistral AI", "mistral"), lv("Zoox", "zoox"), lv("Binance", "binance"),
        lv("Eventbrite", "eventbrite"),
        ab("OpenAI", "openai"), ab("Notion", "notion"), ab("Ramp", "ramp"),
        ab("Linear", "linear"), ab("Perplexity", "perplexity"), ab("Deel", "deel"),
        ab("1Password", "1password"), ab("Vanta", "vanta"), ab("Snowflake", "snowflake"),
        ab("Supabase", "supabase"), ab("Retool", "retool"), ab("Zapier", "zapier"),
        ab("Cohere", "cohere"), ab("Replit", "replit"),
        sr("Visa", "Visa"), sr("Bosch", "BoschGroup")
    )

    fun load(p: SharedPreferences): MutableList<Target> {
        val raw = p.getString("targets", null) ?: return seed.toMutableList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<Target>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Target(o.getString("n"), Ats.valueOf(o.getString("a")), o.getString("s")))
            }
            out
        } catch (e: Exception) {
            seed.toMutableList()
        }
    }

    fun save(p: SharedPreferences, list: List<Target>) {
        val arr = JSONArray()
        for (t in list) {
            arr.put(JSONObject().put("n", t.name).put("a", t.ats.name).put("s", t.slug))
        }
        p.edit().putString("targets", arr.toString()).apply()
    }
}
