package com.snypr.app

import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/** Fires every target in parallel and stops hard when the time budget runs out. */
class Scanner {

    interface Listener {
        fun onHit(job: Job)
        fun onProgress(done: Int, total: Int, jobsSeen: Int, hits: Int)
        fun onFinish(summary: ScanSummary)
    }

    @Volatile
    private var cancelled = false

    fun cancel() {
        cancelled = true
    }

    fun start(targets: List<Target>, f: Filters, budgetMs: Long, l: Listener) {
        val began = System.currentTimeMillis()
        val deadline = began + budgetMs
        val total = targets.size
        val pool = Executors.newFixedThreadPool(POOL) { r ->
            Thread(r, "snypr-worker").apply { isDaemon = true }
        }
        val done = AtomicInteger(0)
        val ok = AtomicInteger(0)
        val failed = AtomicInteger(0)
        val jobsSeen = AtomicInteger(0)
        val hits = AtomicInteger(0)
        val dead = Collections.synchronizedList(ArrayList<Target>())
        val seen = Collections.newSetFromMap(ConcurrentHashMap<String, Boolean>())

        for (t in targets.shuffled()) {
            pool.execute {
                if (cancelled || System.currentTimeMillis() >= deadline - 300L) return@execute
                val res = try {
                    Sources.fetch(t, deadline)
                } catch (e: Exception) {
                    FetchResult(-1, emptyList())
                }
                if (res.code in 200..299) {
                    ok.incrementAndGet()
                    jobsSeen.addAndGet(res.jobs.size)
                    val now = System.currentTimeMillis()
                    for (j in res.jobs) {
                        if (!f.accepts(j, now)) continue
                        val k = if (j.url.isNotBlank()) j.url else j.company + "|" + j.title + "|" + j.postedAt
                        if (seen.add(k)) {
                            hits.incrementAndGet()
                            l.onHit(j)
                        }
                    }
                } else if (res.code == 404 || res.code == 410) {
                    dead.add(t)
                } else if (res.code != Sources.TIMED_OUT) {
                    failed.incrementAndGet()
                }
                if (res.code != Sources.TIMED_OUT) {
                    l.onProgress(done.incrementAndGet(), total, jobsSeen.get(), hits.get())
                }
            }
        }
        pool.shutdown()

        Thread {
            try {
                pool.awaitTermination(budgetMs + 2000L, TimeUnit.MILLISECONDS)
            } catch (e: InterruptedException) {
                // fall through
            }
            pool.shutdownNow()
            val deadList = ArrayList<Target>(dead)
            val okN = ok.get()
            val failedN = failed.get()
            l.onFinish(
                ScanSummary(
                    total = total,
                    ok = okN,
                    dead = deadList,
                    failed = failedN,
                    notReached = total - okN - deadList.size - failedN,
                    jobsSeen = jobsSeen.get(),
                    hits = hits.get(),
                    elapsedMs = System.currentTimeMillis() - began
                )
            )
        }.apply {
            isDaemon = true
            name = "snypr-finish"
        }.start()
    }

    companion object {
        private const val POOL = 16
    }
}
