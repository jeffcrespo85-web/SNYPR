package com.snypr.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    // Palette: night glass, ghillie olive, range-card sand, contact red.
    private val BG = 0xFF0B0E09.toInt()
    private val PANEL = 0xFF141A10.toInt()
    private val LINE = 0xFF2B3622.toInt()
    private val OD = 0xFF5A6B34.toInt()
    private val SAND = 0xFFCDBE8F.toInt()
    private val RED = 0xFFE5502A.toInt()
    private val TXT = 0xFFE3E8D8.toInt()
    private val DIM = 0xFF7D8B6D.toInt()

    private val MONO: Typeface = Typeface.MONOSPACE
    private val MONO_B: Typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    private val STENCIL: Typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val HOUR = 3_600_000L
    private val SCAN_MS = 60_000L
    private val MAX_CARDS = 300

    private val ui = Handler(Looper.getMainLooper())

    private lateinit var prefs: SharedPreferences
    private lateinit var targets: MutableList<Target>
    private var deadKeys: MutableSet<String> = HashSet()

    private lateinit var scope: ScopeView
    private lateinit var fire: TextView
    private lateinit var status: TextView
    private lateinit var results: LinearLayout
    private lateinit var etInclude: EditText
    private lateinit var etExclude: EditText
    private lateinit var etLocation: EditText
    private lateinit var swRemote: Switch
    private lateinit var etUrl: EditText
    private lateinit var btnAdd: TextView
    private lateinit var armoryInfo: TextView
    private val windowButtons = ArrayList<TextView>()

    private var windowMs = 6 * HOUR
    private var scanning = false
    private var scanner: Scanner? = null
    private var seenBefore: Set<String> = HashSet()
    private val hitJobs = ArrayList<Job>()
    private var progDone = 0
    private var progTotal = 0
    private var jobsSeen = 0
    private var endAt = 0L

    private val ticker = object : Runnable {
        override fun run() {
            if (!scanning) return
            val left = maxOf(0L, endAt - System.currentTimeMillis()) / 1000L
            status.text = "SWEEPING  T-" + left + "s   BOARDS " + progDone + "/" + progTotal +
                "   POSTINGS " + jobsSeen + "   CONTACTS " + hitJobs.size
            ui.postDelayed(this, 250L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("snypr", MODE_PRIVATE)
        targets = Armory.load(prefs)
        deadKeys = strSet("dead")
        windowMs = prefs.getLong("window", 6 * HOUR)
        setContentView(buildUi())
        paintWindow()
        styleFire()
        refreshArmory()
    }

    override fun onPause() {
        super.onPause()
        saveFilters()
    }

    // ---------------------------------------------------------------- UI

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rect(fill: Int, stroke: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radiusDp).toFloat()
            setStroke(dp(1), stroke)
        }

    private fun strSet(key: String): MutableSet<String> =
        HashSet<String>(prefs.getStringSet(key, null) ?: emptySet<String>())

    private fun label(t: String): TextView = TextView(this).apply {
        text = t
        setTextColor(DIM)
        textSize = 11f
        typeface = MONO
        letterSpacing = 0.12f
        setPadding(0, dp(18), 0, dp(6))
    }

    private fun field(hintText: String, value: String): EditText = EditText(this).apply {
        setText(value)
        hint = hintText
        setHintTextColor(0xFF4A5740.toInt())
        setTextColor(TXT)
        textSize = 14f
        typeface = MONO
        setSingleLine(true)
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        background = rect(PANEL, LINE, 6)
        setPadding(dp(12), dp(11), dp(12), dp(11))
    }

    private fun buildUi(): View {
        val sv = ScrollView(this).apply {
            setBackgroundColor(BG)
            isFillViewport = true
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(36))
        }
        sv.addView(root, ViewGroup.LayoutParams(MATCH, WRAP))

        root.addView(TextView(this).apply {
            text = "SNYPR"
            setTextColor(SAND)
            typeface = STENCIL
            textSize = 40f
            letterSpacing = 0.3f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Fresh postings, straight from company career boards"
            setTextColor(DIM)
            typeface = MONO
            textSize = 11f
            gravity = Gravity.CENTER
        })

        scope = ScopeView(this)
        root.addView(scope, LinearLayout.LayoutParams(MATCH, dp(250)).apply { topMargin = dp(10) })

        status = TextView(this).apply {
            text = "Standby. Set a window, then acquire targets."
            setTextColor(SAND)
            typeface = MONO
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(10))
        }
        root.addView(status)

        fire = TextView(this).apply {
            gravity = Gravity.CENTER
            typeface = STENCIL
            textSize = 20f
            letterSpacing = 0.2f
            setPadding(0, dp(16), 0, dp(16))
            setOnClickListener { if (scanning) abort() else startScan() }
        }
        root.addView(fire, LinearLayout.LayoutParams(MATCH, WRAP))

        root.addView(label("ENGAGEMENT WINDOW  (posted within the last)"))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((lbl, hrs) in listOf("1 HR" to 1L, "6 HR" to 6L, "24 HR" to 24L)) {
            val b = TextView(this).apply {
                text = lbl
                tag = hrs
                gravity = Gravity.CENTER
                typeface = MONO_B
                textSize = 15f
                setPadding(0, dp(12), 0, dp(12))
                setOnClickListener { setWindow(hrs) }
            }
            row.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                setMargins(dp(3), 0, dp(3), 0)
            })
            windowButtons.add(b)
        }
        root.addView(row)

        root.addView(label("TARGET KEYWORDS  (title contains any, comma separated)"))
        etInclude = field("e.g. soc analyst, data analyst", prefs.getString("inc", "soc analyst, security analyst, data analyst") ?: "")
        root.addView(etInclude)

        root.addView(label("EXCLUDE"))
        etExclude = field("e.g. senior, staff, principal", prefs.getString("exc", "") ?: "")
        root.addView(etExclude)

        root.addView(label("GRID  (location contains any)"))
        etLocation = field("e.g. Indiana, Remote", prefs.getString("loc", "") ?: "")
        root.addView(etLocation)

        swRemote = Switch(this).apply {
            text = "Remote only"
            setTextColor(TXT)
            typeface = MONO
            textSize = 13f
            isChecked = prefs.getBoolean("remote", false)
            setPadding(0, dp(12), 0, dp(4))
        }
        root.addView(swRemote)

        root.addView(label("CONTACTS  (newest first, tap to open the posting)"))
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(results, LinearLayout.LayoutParams(MATCH, WRAP))

        root.addView(label("ARMORY  (company boards SNYPR sweeps)"))
        armoryInfo = TextView(this).apply {
            setTextColor(TXT)
            typeface = MONO
            textSize = 12f
            setPadding(0, 0, 0, dp(8))
        }
        root.addView(armoryInfo)

        val addRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        etUrl = field("Paste a company careers page link", "")
        etUrl.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        addRow.addView(etUrl, LinearLayout.LayoutParams(0, WRAP, 1f))
        btnAdd = TextView(this).apply {
            text = "ADD"
            gravity = Gravity.CENTER
            typeface = MONO_B
            textSize = 14f
            setTextColor(BG)
            background = rect(SAND, SAND, 6)
            setPadding(dp(18), 0, dp(18), 0)
            setOnClickListener { addFromUrl() }
        }
        addRow.addView(btnAdd, LinearLayout.LayoutParams(WRAP, MATCH).apply { leftMargin = dp(8) })
        root.addView(addRow)

        val manage = TextView(this).apply {
            text = "MANAGE ARMORY"
            gravity = Gravity.CENTER
            typeface = MONO_B
            textSize = 13f
            setTextColor(SAND)
            background = rect(PANEL, LINE, 6)
            setPadding(0, dp(12), 0, dp(12))
            setOnClickListener { manageArmory() }
        }
        root.addView(manage, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })

        return sv
    }

    private fun styleFire() {
        if (scanning) {
            fire.text = "ABORT"
            fire.setTextColor(RED)
            fire.background = rect(0xFF2A100A.toInt(), RED, 8)
        } else {
            fire.text = "ACQUIRE TARGETS"
            fire.setTextColor(BG)
            fire.background = rect(SAND, SAND, 8)
        }
    }

    private fun setWindow(hours: Long) {
        windowMs = hours * HOUR
        prefs.edit().putLong("window", windowMs).apply()
        paintWindow()
    }

    private fun paintWindow() {
        for (b in windowButtons) {
            val sel = (b.tag as Long) * HOUR == windowMs
            b.setTextColor(if (sel) BG else DIM)
            b.background = rect(if (sel) SAND else PANEL, if (sel) SAND else LINE, 6)
        }
    }

    private fun saveFilters() {
        if (!::etInclude.isInitialized) return
        prefs.edit()
            .putString("inc", etInclude.text.toString())
            .putString("exc", etExclude.text.toString())
            .putString("loc", etLocation.text.toString())
            .putBoolean("remote", swRemote.isChecked)
            .apply()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ---------------------------------------------------------------- scanning

    private fun startScan() {
        if (targets.isEmpty()) {
            toast("Armory is empty. Paste a careers page link and tap ADD.")
            return
        }
        saveFilters()
        val f = Filters(
            windowMs = windowMs,
            include = Fmt.terms(etInclude.text.toString()),
            exclude = Fmt.terms(etExclude.text.toString()),
            locations = Fmt.terms(etLocation.text.toString()),
            remoteOnly = swRemote.isChecked
        )
        results.removeAllViews()
        hitJobs.clear()
        progDone = 0
        progTotal = targets.size
        jobsSeen = 0
        seenBefore = strSet("seen")
        scanning = true
        styleFire()
        endAt = System.currentTimeMillis() + SCAN_MS
        scope.begin(endAt)
        ui.post(ticker)

        val s = Scanner()
        scanner = s
        s.start(targets.toList(), f, SCAN_MS, object : Scanner.Listener {
            override fun onHit(job: Job) {
                ui.post { if (scanner === s) addHit(job) }
            }

            override fun onProgress(done: Int, total: Int, jobsSeen: Int, hits: Int) {
                ui.post {
                    if (scanner === s) {
                        progDone = done
                        progTotal = total
                        this@MainActivity.jobsSeen = jobsSeen
                        scope.progress = if (total == 0) 0f else done.toFloat() / total
                    }
                }
            }

            override fun onFinish(summary: ScanSummary) {
                ui.post { if (scanner === s) finishScan(summary) }
            }
        })
    }

    private fun abort() {
        scanner?.cancel()
        scanner = null
        scanning = false
        scope.finish()
        styleFire()
        status.text = "Aborted. " + hitJobs.size + " contacts logged."
        rememberSeen()
    }

    private fun finishScan(sm: ScanSummary) {
        scanning = false
        scanner = null
        scope.progress = 1f
        scope.finish()
        styleFire()

        deadKeys.addAll(sm.dead.map { it.key })
        prefs.edit().putStringSet("dead", HashSet<String>(deadKeys)).apply()
        refreshArmory()
        rememberSeen()

        val secs = String.format("%.1f", sm.elapsedMs / 1000.0)
        val sb = StringBuilder()
        sb.append("Sweep complete in ").append(secs).append("s.  ")
        sb.append(sm.ok).append("/").append(sm.total).append(" boards read, ")
        sb.append(sm.jobsSeen).append(" postings checked, ").append(sm.hits).append(" contacts.")
        if (sm.dead.isNotEmpty()) sb.append("  ").append(sm.dead.size).append(" boards not found.")
        if (sm.failed > 0) sb.append("  ").append(sm.failed).append(" failed to respond.")
        if (sm.notReached > 0) sb.append("  ").append(sm.notReached).append(" ran out of time.")
        if (sm.hits == 0) sb.append("\nNothing in this window. Try 24 HR, or loosen the keywords.")
        status.text = sb.toString()
    }

    private fun rememberSeen() {
        val all = strSet("seen")
        for (j in hitJobs) if (j.url.isNotBlank()) all.add(j.url)
        val keep: Set<String> = if (all.size > 4000) {
            hitJobs.filter { it.url.isNotBlank() }.map { it.url }.toHashSet()
        } else {
            all
        }
        prefs.edit().putStringSet("seen", HashSet<String>(keep)).apply()
    }

    private fun addHit(job: Job) {
        if (hitJobs.size >= MAX_CARDS) return
        val idx = hitJobs.count { it.postedAt > job.postedAt }
        hitJobs.add(idx, job)
        results.addView(card(job), idx)
        scope.hitCount = hitJobs.size
        scope.addBlip()
    }

    private fun card(j: Job): View {
        val isNew = j.url.isNotBlank() && j.url !in seenBefore
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rect(PANEL, LINE, 6)
            clipToOutline = true
            setOnClickListener { openUrl(j.url) }
        }
        val stripe = View(this).apply { setBackgroundColor(if (isNew) RED else OD) }
        wrap.addView(stripe, LinearLayout.LayoutParams(dp(4), MATCH))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }

        val head = SpannableStringBuilder()
        if (isNew) {
            val s0 = head.length
            head.append("NEW  ")
            head.setSpan(ForegroundColorSpan(RED), s0, head.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        val s1 = head.length
        head.append(j.company)
        head.setSpan(ForegroundColorSpan(SAND), s1, head.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val s2 = head.length
        head.append("   " + j.ats.label.lowercase())
        head.setSpan(ForegroundColorSpan(DIM), s2, head.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        col.addView(TextView(this).apply {
            text = head
            typeface = MONO_B
            textSize = 12f
        })

        col.addView(TextView(this).apply {
            text = j.title
            setTextColor(TXT)
            typeface = STENCIL
            textSize = 18f
            setPadding(0, dp(3), 0, dp(3))
        })

        val ageMs = System.currentTimeMillis() - j.postedAt
        var foot = "Posted " + Fmt.age(ageMs) + " ago"
        if (j.approx) foot = "Updated " + Fmt.age(ageMs) + " ago (post date not published)"
        if (j.location.isNotBlank()) foot += "   |   " + j.location
        col.addView(TextView(this).apply {
            text = foot
            setTextColor(DIM)
            typeface = MONO
            textSize = 11f
        })

        wrap.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        wrap.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) }
        return wrap
    }

    private fun openUrl(url: String) {
        if (url.isBlank()) return
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: ActivityNotFoundException) {
            toast("No browser found to open this posting.")
        }
    }

    // ---------------------------------------------------------------- armory

    private fun refreshArmory() {
        val flagged = targets.count { it.key in deadKeys }
        var s = targets.size.toString() + " boards loaded"
        if (flagged > 0) s += ", " + flagged + " flagged as not found"
        armoryInfo.text = s
    }

    private fun addFromUrl() {
        val raw = etUrl.text.toString().trim()
        if (raw.isEmpty()) return
        btnAdd.isEnabled = false
        btnAdd.alpha = 0.5f
        Thread {
            val found: List<Target> = try {
                Discover.fromUrl(raw, 8000)
            } catch (e: Exception) {
                emptyList()
            }
            ui.post {
                btnAdd.isEnabled = true
                btnAdd.alpha = 1f
                val known = targets.map { it.key }.toHashSet()
                val fresh = found.filter { it.key !in known }
                if (found.isEmpty()) {
                    toast("No supported hiring system found on that page. SNYPR reads Greenhouse, Lever, Ashby, SmartRecruiters and Recruitee boards.")
                } else if (fresh.isEmpty()) {
                    toast("Already in the armory.")
                } else {
                    targets.addAll(fresh)
                    Armory.save(prefs, targets)
                    etUrl.setText("")
                    refreshArmory()
                    toast("Added: " + fresh.joinToString(", ") { it.name + " (" + it.ats.label.lowercase() + ")" })
                }
            }
        }.start()
    }

    private fun manageArmory() {
        val names = targets.map {
            (if (it.key in deadKeys) "[not found]  " else "") + it.name + "  (" + it.ats.label.lowercase() + "/" + it.slug + ")"
        }.toTypedArray()
        val checked = BooleanArray(targets.size)
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Tick boards to remove")
            .setMultiChoiceItems(names, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Remove ticked") { _, _ ->
                val keep = ArrayList<Target>()
                for (i in targets.indices) if (!checked[i]) keep.add(targets[i])
                targets = keep
                Armory.save(prefs, targets)
                refreshArmory()
            }
            .setNeutralButton("Remove not-found") { _, _ ->
                targets = targets.filter { it.key !in deadKeys }.toMutableList()
                deadKeys.clear()
                prefs.edit().putStringSet("dead", HashSet<String>()).apply()
                Armory.save(prefs, targets)
                refreshArmory()
            }
            .setNegativeButton("Close", null)
            .show()
    }
}
