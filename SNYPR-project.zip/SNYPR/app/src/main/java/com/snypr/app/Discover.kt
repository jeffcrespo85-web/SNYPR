package com.snypr.app

/** Finds which hiring system a company careers page runs on. */
object Discover {

    private val noise = setOf(
        "embed", "v1", "js", "assets", "static", "favicon", "images", "img", "api", "app", "cdn",
        "www", "oneclick-ui", "posting-api", "_next", "s3", "d3"
    )

    private val patterns: List<Pair<Ats, Regex>> = listOf(
        Ats.GREENHOUSE to Regex("""boards-api\.greenhouse\.io/v1/boards/([A-Za-z0-9_-]+)"""),
        Ats.GREENHOUSE to Regex("""greenhouse\.io/(?:embed/job_board(?:/js)?\?for=)?([A-Za-z0-9_-]+)"""),
        Ats.LEVER to Regex("""jobs\.(?:eu\.)?lever\.co/([A-Za-z0-9_.-]+)"""),
        Ats.ASHBY to Regex("""jobs\.ashbyhq\.com/([A-Za-z0-9_.%-]+)"""),
        Ats.ASHBY to Regex("""api\.ashbyhq\.com/posting-api/job-board/([A-Za-z0-9_.%-]+)"""),
        Ats.SMARTRECRUITERS to Regex("""(?:jobs|careers)\.smartrecruiters\.com/([A-Za-z0-9_.-]+)"""),
        Ats.RECRUITEE to Regex("""([a-z0-9-]+)\.recruitee\.com""")
    )

    fun scan(text: String, into: MutableMap<String, Target>) {
        for ((ats, rx) in patterns) {
            for (m in rx.findAll(text)) {
                val slug = m.groupValues[1].trim('.', '-', '/')
                if (slug.isEmpty() || slug.lowercase() in noise) continue
                val t = Target(Fmt.prettyName(slug), ats, slug)
                if (!into.containsKey(t.key) && into.size < 12) into[t.key] = t
            }
        }
    }

    fun fromUrl(raw: String, timeoutMs: Int): List<Target> {
        var url = raw.trim()
        if (url.isEmpty()) return emptyList()
        if (!url.startsWith("http", ignoreCase = true)) url = "https://$url"
        val found = LinkedHashMap<String, Target>()
        scan(url, found)
        if (found.isEmpty()) {
            val r = Http.get(url, timeoutMs)
            val body = r.body
            if (body != null) scan(body.take(2_000_000), found)
        }
        return found.values.toList()
    }
}
