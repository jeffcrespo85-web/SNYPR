package com.snypr.app

enum class Ats(val label: String) {
    GREENHOUSE("GREENHOUSE"),
    LEVER("LEVER"),
    ASHBY("ASHBY"),
    SMARTRECRUITERS("SMARTRECRUITERS"),
    RECRUITEE("RECRUITEE")
}

data class Target(val name: String, val ats: Ats, val slug: String) {
    val key: String get() = ats.name + ":" + slug.lowercase()
}

data class Job(
    val company: String,
    val title: String,
    val location: String,
    val url: String,
    val postedAt: Long,
    /** true when the source only gave a "last updated" time, not a real post date */
    val approx: Boolean,
    val remote: Boolean,
    val ats: Ats
)

data class Filters(
    val windowMs: Long,
    val include: List<String>,
    val exclude: List<String>,
    val locations: List<String>,
    val remoteOnly: Boolean
) {
    fun accepts(j: Job, now: Long): Boolean {
        val age = now - j.postedAt
        if (age > windowMs || age < -600_000L) return false
        val title = j.title.lowercase()
        if (include.isNotEmpty() && include.none { title.contains(it) }) return false
        if (exclude.any { title.contains(it) }) return false
        if (remoteOnly) return j.remote
        if (locations.isNotEmpty()) {
            val loc = j.location.lowercase()
            if (locations.none { loc.contains(it) }) return false
        }
        return true
    }
}

data class FetchResult(val code: Int, val jobs: List<Job>)

data class ScanSummary(
    val total: Int,
    val ok: Int,
    val dead: List<Target>,
    val failed: Int,
    val notReached: Int,
    val jobsSeen: Int,
    val hits: Int,
    val elapsedMs: Long
)

object Fmt {
    fun age(ms: Long): String {
        val m = maxOf(0L, ms / 60_000L)
        return when {
            m < 1L -> "<1m"
            m < 60L -> "${m}m"
            else -> "${m / 60}h ${m % 60}m"
        }
    }

    fun terms(s: String): List<String> =
        s.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }

    fun prettyName(slug: String): String =
        slug.replace('-', ' ').replace('_', ' ').replace('.', ' ')
            .split(' ').filter { it.isNotBlank() }
            .joinToString(" ") { w -> w.replaceFirstChar { c -> c.uppercase() } }
}
