package com.snypr.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Rifle-scope reticle. Sweeps while a scan runs, drops a red blip for every contact. */
class ScopeView(ctx: Context) : View(ctx) {

    private val sand = Color.parseColor("#CDBE8F")
    private val olive = Color.parseColor("#5A6B34")
    private val sweepGreen = Color.parseColor("#7FA34A")
    private val red = Color.parseColor("#E5502A")

    var scanning = false
        private set
    var hitCount = 0
    var progress = 0f
    private var endAt = 0L
    private var startedAt = 0L

    private class Blip(val angle: Float, val radius: Float, val born: Long)

    private val blips = ArrayList<Blip>()
    private val rnd = java.util.Random()

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    }
    private val sweepPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val arc = RectF()

    private fun dp(v: Float) = v * resources.displayMetrics.density

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        sweepPaint.shader = SweepGradient(
            w / 2f, h / 2f,
            intArrayOf(Color.TRANSPARENT, Color.argb(130, 127, 163, 74)),
            floatArrayOf(0.78f, 1f)
        )
    }

    fun begin(endAtMs: Long) {
        scanning = true
        startedAt = System.currentTimeMillis()
        endAt = endAtMs
        blips.clear()
        hitCount = 0
        progress = 0f
        postInvalidateOnAnimation()
    }

    fun finish() {
        scanning = false
        invalidate()
    }

    fun reset() {
        scanning = false
        blips.clear()
        hitCount = 0
        progress = 0f
        invalidate()
    }

    fun addBlip() {
        if (blips.size >= 40) blips.removeAt(0)
        val a = rnd.nextFloat() * 6.2831853f
        val r = 0.22f + rnd.nextFloat() * 0.62f
        blips.add(Blip(a, r, System.currentTimeMillis()))
    }

    override fun onDraw(c: Canvas) {
        val now = System.currentTimeMillis()
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - dp(8f)
        val inner = r - dp(10f)

        // lens + housing
        fill.color = Color.parseColor("#050704")
        c.drawCircle(cx, cy, r, fill)
        stroke.color = olive
        stroke.strokeWidth = dp(6f)
        c.drawCircle(cx, cy, r, stroke)
        stroke.color = Color.parseColor("#2B3622")
        stroke.strokeWidth = dp(1f)
        c.drawCircle(cx, cy, inner, stroke)
        c.drawCircle(cx, cy, inner * 0.66f, stroke)
        c.drawCircle(cx, cy, inner * 0.33f, stroke)

        // sweep
        if (scanning) {
            val ang = ((now - startedAt) % 2600L) / 2600f * 360f
            c.save()
            c.rotate(ang, cx, cy)
            c.drawCircle(cx, cy, inner, sweepPaint)
            stroke.color = sweepGreen
            stroke.strokeWidth = dp(1.5f)
            c.drawLine(cx, cy, cx + inner, cy, stroke)
            c.restore()
        }

        // reticle: thin full cross, thick outer arms, mil-dots
        stroke.color = sand
        stroke.strokeWidth = dp(1f)
        stroke.alpha = 150
        val gap = inner * 0.07f
        c.drawLine(cx - inner, cy, cx - gap, cy, stroke)
        c.drawLine(cx + gap, cy, cx + inner, cy, stroke)
        c.drawLine(cx, cy - inner, cx, cy - gap, stroke)
        c.drawLine(cx, cy + gap, cx, cy + inner, stroke)
        stroke.alpha = 255
        stroke.strokeWidth = dp(3.5f)
        c.drawLine(cx - inner, cy, cx - inner * 0.55f, cy, stroke)
        c.drawLine(cx + inner * 0.55f, cy, cx + inner, cy, stroke)
        c.drawLine(cx, cy - inner, cx, cy - inner * 0.55f, stroke)
        c.drawLine(cx, cy + inner * 0.55f, cx, cy + inner, stroke)
        fill.color = sand
        for (i in 1..4) {
            val d = inner * 0.11f * i
            c.drawCircle(cx - d, cy, dp(1.8f), fill)
            c.drawCircle(cx + d, cy, dp(1.8f), fill)
            c.drawCircle(cx, cy - d, dp(1.8f), fill)
            c.drawCircle(cx, cy + d, dp(1.8f), fill)
        }

        // contacts
        for (b in blips) {
            val bx = cx + cos(b.angle) * b.radius * inner
            val by = cy + sin(b.angle) * b.radius * inner
            val life = (now - b.born) / 1800f
            if (life < 1f && scanning) {
                stroke.color = red
                stroke.strokeWidth = dp(1.5f)
                stroke.alpha = ((1f - life) * 255).toInt()
                c.drawCircle(bx, by, dp(4f) + life * dp(16f), stroke)
                stroke.alpha = 255
            }
            fill.color = red
            c.drawCircle(bx, by, dp(3.2f), fill)
        }

        // progress arc on the housing edge
        if (progress > 0f) {
            stroke.color = sand
            stroke.strokeWidth = dp(3f)
            arc.set(cx - r, cy - r, cx + r, cy + r)
            c.drawArc(arc, -90f, 360f * progress.coerceIn(0f, 1f), false, stroke)
        }

        // readouts
        text.color = sand
        text.textSize = dp(12f)
        c.drawText("CONTACTS " + hitCount, cx, cy - inner * 0.50f, text)
        text.textSize = dp(22f)
        val label = if (scanning) {
            "T-" + (maxOf(0L, endAt - now) / 1000L) + "s"
        } else {
            "STANDBY"
        }
        c.drawText(label, cx, cy + inner * 0.60f, text)

        if (scanning) postInvalidateOnAnimation()
    }
}
